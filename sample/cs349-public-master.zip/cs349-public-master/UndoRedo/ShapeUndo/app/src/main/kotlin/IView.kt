interface IView {
    public fun update()
}