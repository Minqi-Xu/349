fun main() {
    // immutable variables
    val a = 1.0

    // a = 2.0

    // val b

// mutable variables

    var c = 0
    c = 5
    // c = "abc"

}