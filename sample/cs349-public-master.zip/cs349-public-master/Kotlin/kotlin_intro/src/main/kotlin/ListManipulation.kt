fun main() {
    val list = listOf("one", "two", "three", "four")
    println(list.slice(0..3 step 2))

}