
// class Human is just a different syntax

class Human() {
    fun talk() {
        println("I am a human being!")
    }
}

fun main() {
    val p = Human()
    p.talk()
}
