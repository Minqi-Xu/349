interface IObserver {
    fun update()
}