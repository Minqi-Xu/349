interface IViewModel {
    fun update()
}