interface IView {
    fun update()
}