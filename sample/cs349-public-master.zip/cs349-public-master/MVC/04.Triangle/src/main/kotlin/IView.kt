import javafx.beans.value.ChangeListener

interface IView {
    fun updateView()

}