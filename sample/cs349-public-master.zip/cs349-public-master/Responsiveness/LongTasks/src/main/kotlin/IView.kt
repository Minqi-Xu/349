
interface IView {
    /**
     * Something of significance happened in the observed object.
     */
    fun update()
}