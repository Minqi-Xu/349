import javafx.scene.canvas.Canvas

internal interface IShape {
    fun draw(canvas: Canvas?)
}