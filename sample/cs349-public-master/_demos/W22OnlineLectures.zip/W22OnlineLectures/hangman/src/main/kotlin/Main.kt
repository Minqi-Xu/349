import javafx.application.Application
import javafx.scene.Scene
import javafx.scene.layout.*
import javafx.stage.Stage

class Main : Application() {
    override fun start(stage: Stage) {

        // setup the layout
        val main = BorderPane()

        val right = VBox()
        right.children.addAll(LetterView(), CommandView())

        main.right = right
        main.bottom = MessageView()
        main.center = GraphicsView()

        // display the scene
        val scene = Scene(main)
        stage.scene = scene

        stage.minWidth = 500.0
        stage.minHeight = 500.0
        stage.show()
    }
}