import javafx.scene.control.Button
import javafx.scene.layout.Background
import javafx.scene.layout.BackgroundFill
import javafx.scene.layout.TilePane
import javafx.scene.paint.Color

class CommandView : TilePane() {
    init {
        minHeight = 100.0
        background = Background(BackgroundFill(Color.LIGHTSEAGREEN, null, null))
    }
}