import javafx.scene.control.Button
import javafx.scene.layout.*

class LetterView: TilePane() {
    init {
        for (l in 'A'..'Z') {
            val b = Button(l.toString())
            b.prefWidth = 50.0
            children.add(b)
        }
        prefWidth = 100.0
    }
}