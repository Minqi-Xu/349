import javafx.scene.control.*
import javafx.scene.layout.*
import javafx.scene.paint.Color

class MessageView : StackPane() {
    init {
        minHeight = 30.0
        children.add(Label("Game Messages"))
        background = Background(BackgroundFill(Color.LIGHTPINK, null, null))
    }
}
