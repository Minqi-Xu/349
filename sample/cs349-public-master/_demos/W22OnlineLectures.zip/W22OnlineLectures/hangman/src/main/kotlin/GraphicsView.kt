import javafx.scene.layout.*
import javafx.scene.paint.*

class GraphicsView : Pane() {

    init {
        minWidth = 300.0
        minHeight = 300.0
        background = Background(BackgroundFill(Color.LIGHTGREEN, null, null))
    }
}