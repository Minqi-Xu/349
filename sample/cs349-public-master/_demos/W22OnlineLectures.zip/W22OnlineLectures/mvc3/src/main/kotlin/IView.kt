interface IView {
    fun updateView()
}