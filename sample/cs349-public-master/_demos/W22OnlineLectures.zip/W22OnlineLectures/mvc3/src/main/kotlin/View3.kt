import javafx.scene.control.Spinner
import javafx.scene.control.TextFormatter
import javafx.scene.layout.StackPane

class View3(
    private val model: Model
    ) : StackPane(), IView {

    override fun updateView() {
        println("View3: updateView")
        spinner.valueFactory.value = model.counterValue
    }

    val spinner = Spinner<Int>(0, Int.MAX_VALUE, 0)

    init {
        children.add(spinner)
        // can make it editable, but be sure to enter numbers!
//        spinner.isEditable = true

        spinner.valueProperty().addListener { obj, old, new ->
            model.counterValue = new
        }
        // register with the model when we're ready to start receiving data
        model.addView(this)
    }
}