# Selected Code from W22 Lectures

**Warnings** 

* Note all code is posted.

* This code may only make sense with your notes taken in lecture. It is not intended as a self-documenting example. 
  
* Since this code is the result of a live coding session, it may be incomplete, use short variable names, is poorly commented, take shortcuts, etc.  