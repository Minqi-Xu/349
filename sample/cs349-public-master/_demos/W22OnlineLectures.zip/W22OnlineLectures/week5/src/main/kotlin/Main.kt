import javafx.application.Application
import javafx.geometry.VPos
import javafx.scene.Group
import javafx.scene.Scene
import javafx.scene.canvas.Canvas
import javafx.scene.canvas.GraphicsContext
import javafx.scene.control.Button
import javafx.scene.input.MouseEvent
import javafx.scene.layout.*
import javafx.scene.paint.Color
import javafx.scene.shape.Ellipse
import javafx.scene.shape.Line
import javafx.scene.shape.Polygon
import javafx.scene.shape.Rectangle
import javafx.scene.text.*
import javafx.scene.transform.Transform
import javafx.stage.Stage

// Draw using a canvas class instead.
class Main : Application() {
    override fun start(stage: Stage) {

        // Create a scene graph with a root node
        // This will hold the objects that we want to display on the stage
        val root = StackPane()

        // Create a canvas as a drawing surface
        val canvas = Canvas(300.0, 300.0)

        // Use the graphics context to draw on a canvas
        val gc = canvas.graphicsContext2D

        // draw GC grid
//        grid(0.0, 0.0, 300.0, 10.0, gc)

        // add Grid shape
        val myGrid = grid2(0.0, 0.0, 300.0, 10.0)
        root.children.add(myGrid)

        // to see the canvas (try putting canvas in StackPane to see 0,0)
//        gc.fill = Color.DARKGRAY
//        gc.fillRect(0.0, 0.0, canvas.width, canvas.height)

//        gc.fill = Color.BLUE
//        gc.fillRect(100.0, 100.0, 100.0, 100.0)
//        gc.lineWidth = 5.0
//        gc.stroke = Color.WHITE
//        gc.fill = Color.RED
//        gc.fillRect(75.0, 75.0, 100.0, 100.0)
//        gc.strokeRect(75.0, 75.0, 100.0, 100.0)
//        gc.fill = Color.GREEN
//        gc.fillRect(125.0, 125.0, 100.0, 100.0)

        // complex shape
//        gc.fill = Color.GREEN
//        val ptsx = doubleArrayOf(0.0, 100.0, 100.0, 50.0, 0.0)
//        val ptsy = doubleArrayOf(150.0, 150.0, 50.0, 0.0, 50.0)
//        gc.fillPolygon(ptsx, ptsy, ptsx.size)

        // text demo
//        gc.lineWidth = 2.0
//        gc.stroke = Color.WHITE
//        gc.strokeRect(100.0, 100.0, 100.0, 100.0)
//        gc.fill = Color.WHITE
//        gc.font = Font(40.0)
//        gc.textAlign = TextAlignment.CENTER
//        gc.textBaseline = VPos.CENTER
//        gc.fillText("Hello", 150.0, 150.0)

        // Rectangle Shape
//        val rect = Rectangle(75.0, 75.0, 100.0, 100.0)
//        rect.fill = Color.RED
//        rect.stroke = Color.WHITE
//        rect.strokeWidth = 5.0
//        root.children.add(rect)

        // Polygon Shape
        var pts = doubleArrayOf(0.0, 150.0, 100.0, 150.0, 100.0, 50.0, 50.0, 0.0, 0.0, 50.0)
        val poly = Polygon(*pts)
        poly.fill = Color.LIGHTGREEN
//        root.children.add(poly)

        // move pivot
        poly.transforms.add(Transform.translate(0.0, 75.0))

        // display pivot
        val pivot = Ellipse(poly.boundsInLocal.centerX, poly.boundsInLocal.centerY, 5.0, 5.0)
//        root.children.add(pivot)


        // Shape transformations
//        poly.translateX = 100.0
//        poly.translateY = 60.0
//        poly.scaleX = 1.25
//        poly.scaleY = 1.25
//        poly.rotate = 45.0

        // transform a button too
        val b = Button("Hello")
        b.prefWidth = 100.0
        b.prefHeight = 100.0
        root.children.add(b)

        // can also transform a Pane
        root.rotate = 30.0

        // interactive rotate and scale
//        var px: Double? = null
//        var py: Double? = null
//
//        stage.addEventFilter(MouseEvent.MOUSE_MOVED) { e ->
//            val dx = e.x - (px ?: e.x)
//            b.rotate += dx
//            px = e.x
//
//            val dy = e.y - (py ?: e.y)
//            b.scaleY += dy / 100.0
//            b.scaleX += dy / 100.0
//            py = e.y
//        }

        // SIMPLER interactive rotate and scale
        stage.addEventFilter(MouseEvent.MOUSE_MOVED) { e ->
            b.rotate = e.x * 2.0

            val s = (e.y - 150.0) / 75.0
            b.scaleY = s
            b.scaleX = s
        }

        // Add the canvas to the scene
        root.children.add(canvas)
        val scene = Scene(root, 300.0, 300.0, Color.WHITE)

        // Add the scene to the stage and show it
        stage.title = "Drawing Canvas"
        stage.scene = scene
        stage.show()
    }
}


fun grid(x: Double, y: Double, wh: Double, s: Double, gc: GraphicsContext) {

    gc.lineWidth = 1.0
    gc.stroke = Color.LIGHTGRAY

    var i = 0.0
    while (i <= wh) {
        gc.strokeLine(x + i, y, x + i, y + wh)
        gc.strokeLine(x, y + i, x + wh, y + i )
        i += s
    }
}

fun grid2(x: Double, y: Double, wh: Double, s: Double): Group {

    val group = Group()
    var i = 0.0
    while (i <= wh) {

        val hline = Line(x + i, y, x + i, y + wh)
        hline.stroke = Color.DARKGRAY
        hline.strokeWidth = 1.0
        group.children.add(hline)

        val vline = Line(x, y + i, x + wh, y + i )
        vline.stroke = Color.DARKGRAY
        vline.strokeWidth = 1.0
        group.children.add(vline)

        i += s
    }
    return group
}

