import javafx.application.Application
import javafx.application.Platform
import javafx.scene.Scene
import javafx.scene.control.*
import javafx.scene.image.Image
import javafx.scene.image.ImageView
import javafx.scene.layout.BorderPane
import javafx.scene.layout.Pane
import javafx.scene.layout.VBox
import javafx.stage.Stage

class Main : Application() {
    override fun start(stage: Stage) {

        // CREATE WIDGETS TO DISPLAY
        // menubar & toolbar
        val menuBar = MenuBar()
        val fileMenu = Menu("File")
        val editMenu = Menu("Edit")
        val viewMenu = Menu("View")

        val menuNew = MenuItem("New")
        val menuOpen = MenuItem("Open")
        val menuClose = MenuItem("Close")
        val menuQuit = MenuItem("Quit")
        menuQuit.setOnAction { Platform.exit() }

        fileMenu.items.addAll(menuNew, menuOpen, menuClose, menuQuit)
        menuBar.menus.addAll(fileMenu, editMenu, viewMenu)

        val toolbar = ToolBar()
        val button1 = Button("New")
        button1.setOnAction { println("button1") }
        val button2 = Button("Open")
        toolbar.items.addAll(button1, button2)

        // stack menu and toolbar in the top region
        val vbox = VBox(menuBar, toolbar)

        // panel on left side, need to replace with a tree
        val pane = Pane()
        pane.prefWidth = 100.0
        pane.prefHeight = 600.0
        pane.style = "-fx-background-color: black;"

        // image in the centre
        val image = ImageView(Image("Bailey.png"))

        // SETUP LAYOUT
        val border = BorderPane()
        border.top = vbox
        border.left = pane
        border.center = image

        // CREATE AND SHOW SCENE
        val scene = Scene(border, 800.0, 600.0)
        stage.scene = scene
        stage.title = "A1 Demo"
        stage.show()
    }
}